package MT::App::OpenID;

use strict;
use MT;
use MT::App;
use MT::Util;
use Net::OpenID::Server;
use File::Spec;
use vars qw(@ISA);
@ISA = 'MT::App';

sub init {
    my $app = shift;
    $app->SUPER::init(@_) or return;
    $app->add_methods(
        openid => \&openid,
        trust  => \&trust,
    );
    $app->{default_mode} = 'openid';
    my $mode = $app->{query}->param('__mode');
    $app->{requires_login} = 1 if $mode && $mode eq 'trust';
    $app->{plugin_template_path} = File::Spec->catdir($app->{mt_dir}, 'plugins', 'openid-server', 'tmpl');
    $app;
}

sub trust {
    my $app = shift;
    my $q = $app->{query};
    my %param;

    ## We're logged in, so just redirect, until we have actual trusting.
    my @params = grep { !/__mode/ && !/username/ && !/password/ && !/submit/ } $q->param;
    my $uri = $app->uri . '?openid.mode=checkid_setup&openid.identity=';
    $uri .= MT::Util::encode_url($q->param('identity'));
    $uri .= '&openid.return_to=';
    $uri .= MT::Util::encode_url($q->param('return_to'));
    $uri .= '&openid.trust_root=';
    $uri .= MT::Util::encode_url($q->param('trust_root'));

    $app->redirect($uri);
}

sub is_identity {
    my ($app, $u, $identity_url) = @_;
    return 0 unless $u;
    my $author_url = $u->url;
    $author_url =~ m(^$identity_url);
}

sub is_trusted {
    my ($app, $u, $trust_root, $is_identity) = @_;
    ## TODO: use saved trust too
    return 0 unless defined($u) && $is_identity;
    #$app->{query}->param('trust_once') ? 1 : 0;
    1;
}

sub _build_nos {
    my $app = shift;
    my $nos = Net::OpenID::Server->new(
        get_args      => $app->{query},
        post_args     => $app->{query},
        server_secret => sub { $app->make_secret($_[0]) },
        get_user      => sub { ($app->{author}) = $app->login; $app->{author} },
        is_identity   => sub { $app->is_identity(@_) },
        is_trusted    => sub { $app->is_trusted(@_) },
        setup_url     => ($app->uri . '?__mode=trust'),
    );
    $nos;
}

sub openid {
    my $app = shift;
    my $nos = $app->_build_nos;
    my ($type, $data) = $nos->handle_page;
    if ($type eq "redirect") {
        $app->redirect($data);
    } elsif($type eq 'setup') {
        ## Was it an identity or trust failure? Cancel.
        return $app->error('Your account is not authorized to assert the requested identity.')
            if $app->{author};

        my $url = $nos->setup_url;
        $url .= '&'. $_ .'='. MT::Util::encode_url($data->{$_})
            for qw( trust_root return_to identity assoc_handle );
        $app->redirect($url);
    } else {
        $app->response_content_type($type);
        return $data || "This is Movable Type's OpenID server endpoint, not a human-readable resource.  For more information, see <a href='http://openid.net/'>http://openid.net/</a>.<br /><br />Get <a href='?openid.mode=getpubkey'>public key</a>.";
    }
}

sub make_secret {
    my $app = shift;
    my ($time) = @_;
    #require MT::Session;
    #my $sess = MT::Session->get_unexpired_value();
    return $time;
}

1;
