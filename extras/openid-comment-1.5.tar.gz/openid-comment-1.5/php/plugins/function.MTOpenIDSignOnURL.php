<?php
function smarty_function_MTOpenIDSignOnURL($args, &$ctx) {
    $cgipath = $ctx->tag('CGIPath');
    return $cgipath . 'plugins/openid-comment/signon.cgi';
}
?>
