#!/usr/bin/perl

use MT;
use MT::Plugin;

package MT::Plugin::OpenIDComment;

our $VERSION = '1.5';

our $plugin_obj = MT::Plugin->new({
    name => 'OpenID Comments',
    version => $VERSION,
    description => 'Empowers commenters to sign in with OpenID to comment',

    settings => MT::PluginSettings->new([
        ['enable',     { Default => 1, Scope => 'blog' }],
        ['special_lj', { Default => 1, Scope => 'blog' }],
    ]),
    blog_config_template => 'blog_config.tmpl',
});
MT->add_plugin($plugin_obj);

sub instance { $plugin_obj; }


MT::Template::Context->add_tag(CommentAuthorIdentity => \&identity_link);
MT::Template::Context->add_tag(OpenIDSignOnURL => \&signon_url);
MT::Template::Context->add_tag(OpenIDSignOnThunk => \&signon_thunk);
MT::Template::Context->add_tag(LiveJournalSignOnThunk => \&signon_thunk);

sub schema_version { 1 }

sub identity_link {
    my ($ctx, $args) = @_;
    my $cmt = $ctx->stash('comment')
        or return $ctx->_no_comment_error('MT' . $ctx->stash('tag'));
    my $config = $plugin_obj->get_config_hash('blog:'. $ctx->stash('blog_id'));
    ## Don't check for enablement here, so we can handle if OpenID comments are made,
    ## then OpenID is disabled.
    if($cmt->commenter_id) {
        require MT::Author;
        my $auth = MT::Author->load($cmt->commenter_id) or return "?";
        my $name = $auth->name;
        if($name =~ m(^openid\n)) {
            my $cfg = MT::ConfigMgr->instance;
            my $assets_path = MT::Template::Context::_hdlr_static_path($ctx, {}) . 'openid-comment';

            require MT::Plugin::OpenIDIdentity;
            my $id = MT::Plugin::OpenIDIdentity->load({ author_id => $auth->id });
            my $identity = $id->url;

            if($config->{special_lj}) {
                if( $identity =~ m(^http://www\.livejournal\.com\/users/[^/]+/$) ||
                    $identity =~ m(^http://www\.livejournal\.com\/~[^/]+/$) ||
                    $identity =~ m(^http://[^\.]+\.livejournal\.com\/$)
                ) {
                    return qq(<a class="commenter-profile" href="${identity}info"><img alt="[LiveJournal user info]" src="$assets_path/livejournal.gif" width="17" height="17" /></a>);
                }
            }
            return qq(<a class="commenter-profile" href="$identity"><img alt="[OpenID Commenter Profile]" src="$assets_path/openid.gif" width="16" height="16" /></a>);
        }
    }
    return $ctx->_hdlr_comment_author_identity($args);
}

sub signon_url {
    my ($ctx, $args) = @_;
    my $cgipath = $ctx->_hdlr_cgi_path;
    "${cgipath}plugins/openid-comment/signon.cgi";
}

sub signon_thunk {
    my ($ctx, $args) = @_;
    my $signon_url = signon_url($ctx, $args);
    my $assets_path = MT::Template::Context::_hdlr_static_path($ctx, {}) . 'openid-comment';
    my $entry_id = $ctx->stash('entry')->id;

    my $livejournal = $ctx->stash('tag') eq 'LiveJournalSignOnThunk' ? 1 : 0;
    my $field_label = $livejournal ? 'Your LiveJournal username' : 'Your blog URL';
    my $field_name  = $livejournal ? 'lj_user' : 'openid_url';
    my $image_name  = $livejournal ? 'livejournal' : 'openid';
    
    <<EOF;
<div id="signon-$image_name">
<form method="post" action="$signon_url">
<input type="hidden" name="entry_id" value="$entry_id" />
<input type="hidden" name="__mode" value="signon" />
<p>
<label for="$field_name">$field_label:</label> <input class="identity" id="$field_name" name="$field_name" size="30" value="" style="background: white url($assets_path/$image_name.gif) no-repeat; padding-left: 18px;" />
<input class="signin" type="submit" value="Sign in" />
</p>
</form>
</div>
EOF
}

MT->add_callback('bigpapi::template::list_commenters', 5, $plugin_obj, sub {
    my ($cb, $app, $template) = @_;
    $$template =~ s((?<=<TMPL_VAR NAME=PROFILE_PAGE>)/)()s;
});

sub _fix_identity {
    my ($author_id, $blog_id) = @_;
    my ($author_name, $author_url, $is_livejournal);
    
    require MT::Plugin::OpenIDIdentity;
    my $id = MT::Plugin::OpenIDIdentity->load({ author_id => $author_id })
        or return $app->error('No OpenID identity for openid\n author');
    my $identity = $id->url;
   
    my $profile_url = $identity;
    my $special_lj = $plugin_obj->get_config_value('special_lj', 'blog:' . $blog_id);
    if($special_lj && (
        $identity =~ m(^http://www\.livejournal\.com\/users/[^/]+/$) ||
        $identity =~ m(^http://www\.livejournal\.com\/~[^/]+/$) ||
        $identity =~ m(^http://[^\.]+\.livejournal\.com\/$)
    )) {
        $profile_url .= 'info';
    }
    
    my $display_url = $identity;
    $display_url =~ s(^\w+://)();
    $display_url =~ s((?<=^.{40}).+)(...)s;

    return ($display_url, $profile_url);
}

MT->add_callback('bigpapi::param::list_commenters', 5, $plugin_obj, sub {
    my ($cb, $app, $param) = @_;

    my $special_lj = $plugin_obj->get_config_value('special_lj', 'blog:' . $param->{blog_id});
    
    for my $table (@{ $param->{commenter_table} }) {
        for my $cmtr (@{ $table->{object_loop} }) {
            if($cmtr->{author} =~ m(^openid\n)) {
                ($cmtr->{author}, $cmtr->{profile_page}) = _fix_identity(
                    $cmtr->{author_id}, $param->{blog_id});
            }
        }
    }
});

MT->add_callback('bigpapi::param::edit_commenter', 5, $plugin_obj, sub {
    my ($cb, $app, $param) = @_;
    if($param->{name} =~ m(^openid\n)) {
        ($param->{name}, $param->{profile_page}) = _fix_identity(
            $param->{id}, $param->{blog_id});
    }
});


1;

