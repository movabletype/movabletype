<?php
# redefinition and config fetching technique borrowed from
# init.nofollow.php under Artistic License

global $mt;
$ctx = &$mt->context();

# override handler for the following tags.  the overridden version
# will, in turn call the MT native handlers...
$ctx->register_function('MTCommentAuthorIdentity', 'mtcommentauthoridentity_openid');

function openidcomment_config($ctx) {
    $config = $ctx->stash('openidcomment_config');
    if ($config)
        return $config;
    $blog_id = $ctx->stash('blog_id');
    $config = $ctx->mt->db->fetch_plugin_config('OpenID Comments', 'blog:' . $blog_id);
    if (!$config)
        $config = array('enable' => 1, 'special_lj' => 1);
    if(!array_key_exists('enable', $config))
        $config['enable'] = 1;
    if(!array_key_exists('special_lj', $config))
        $config['special_lj'] = 1;
    $ctx->stash('openidcomment_config', $config);
    return $config;
}

function mtcommentauthoridentity_openid($args, &$ctx) {
    ## Just explode messily when lacking comment? Okay...
    $comment = $ctx->stash('comment');
    $config = openidcomment_config($ctx);
    if($comment['comment_commenter_id']) {
        $author = $ctx->mt->db->fetch_author($comment['comment_commenter_id']);
        $name = $author['author_name'];
        if(strpos($name, "openid\n") === 0) {
            $assets_path = $ctx->tag('StaticWebPath') . "openid-comment";

            $identity = $ctx->mt->db->get_var("
                SELECT openididentity_url
                FROM   mt_openididentity
                WHERE  openididentity_author_id=" .
                $author['author_id']);

            if($config['special_lj']) {
                if(preg_match('!^http://www\.livejournal\.com/users/[^/]+/$!', $identity)
                    || preg_match('!^http://www\.livejournal\.com/~[^/]+/$!', $identity)
                    || preg_match('!^http://[^\.]+\.livejournal\.com/$!', $identity))
                {
                    return '<a class="commenter-profile" href="' . $identity
                        . 'info"><img alt="[LiveJournal user info]" src="'
                        . $assets_path . '/livejournal.gif" width="17" height="17" /></a>';
                }
            }

            return '<a class="commenter-profile" href="' . $identity
                . '"><img alt="[OpenID Commenter Profile]" src="'
                . $assets_path . '/openid.gif" width="16" height="16" /></a>';
        }
    }
    require_once('function.MTCommentAuthorIdentity.php');
    return smarty_function_MTCommentAuthorIdentity($args, $ctx);
}

?>
