<?php
function smarty_function_MTOpenIDSignOnThunk($args, &$ctx) {
    $signon_url = $ctx->tag('OpenIDSignOnURL');

    $spath = $ctx->tag('StaticWebPath');
    $assets_path = $spath . 'openid-comment';
    $entry = $ctx->stash('entry');
    if (!$entry) return '';

    $entry_id = $entry['entry_id'];
    $field_label = 'Your blog URL';
    $field_name  = 'openid_url';
    $image_name  = 'openid';

    $form = '<div id="openid">';
    $form .= '<form method="post" action="' . $signon_url . '">';
    $form .= '<input type="hidden" name="entry_id" value="' . $entry_id . '" />';
    $form .= '<input type="hidden" name="__mode" value="signon" />';
    $form .= '<p>';
    $form .= '<label>' . $field_label . ':</label> <input name="' . $field_name . '" size="35" value="" style="background: white url(' . $assets_path . '/' . $image_name . '.gif) no-repeat; padding-left: 18px;" />';
    $form .= '<input type="submit" value="Sign in" />';
    $form .= '</p></form></div>';
    return $form;
}
?>
