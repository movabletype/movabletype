#!/usr/bin/perl -w

package MT::Plugin::OpenIDIdentity;
use strict;

use MT::Object;
@MT::Plugin::OpenIDIdentity::ISA = qw( MT::Object );

__PACKAGE__->install_properties({
    column_defs => {
        'id' => 'integer not null auto_increment',
        'author_id' => 'integer not null',
        'url' => 'string(255)',
    },
    indexes => {
        url => 1,
        author_id => 1,
    },
    datasource => 'openididentity',
    primary_key => 'id',
});

sub author {
    my ($id) = @_;
    return $id->{__author} if $id->{__author};
    require MT::Author;
    $id->{__author} = MT::Author->load($id->author_id);
}

1;

